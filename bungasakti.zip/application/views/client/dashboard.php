<div class="container-xxl mt-3">
    <h3>Welcome, <?php echo $this->session->userdata('sessionUsernameCustomer'); ?> 😊</h3>
</div>