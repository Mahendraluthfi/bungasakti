<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penjualan extends CI_Controller
{

    public function index()
    {
    }
}

/* End of file Penjualan.php */
